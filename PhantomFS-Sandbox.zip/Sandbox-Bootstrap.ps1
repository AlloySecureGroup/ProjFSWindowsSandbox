#requires -version 5.1
# ============================================================================
# PhantomFS in Windows Sandbox - in-sandbox bootstrap
# ----------------------------------------------------------------------------
# Runs INSIDE Windows Sandbox as the sandbox logon command. It:
#   1. Installs the host-matched ProjFS binaries and loads the PrjFlt
#      minifilter (Windows Sandbox does not ship ProjFS enabled).
#   2. Unzips the bundled PhantomFS release into a writable sandbox path.
#   3. Launches PhantomFS.exe against a virtual honeypot root and opens it.
#
# Everything under C:\Sandbox\Read is mapped read-only from the host, so the
# PhantomFS zip is expanded into C:\PhantomFS (writable) before it is run.
# Logs land in C:\Sandbox\Write, which survives after the sandbox closes.
# ============================================================================
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

$read = 'C:\Sandbox\Read'
$write = 'C:\Sandbox\Write'
$log = Join-Path $write 'sandbox-bootstrap.log'
New-Item -ItemType Directory -Path $write -Force | Out-Null
Start-Transcript -Path $log -Force | Out-Null

# PhantomFS install/runtime locations inside the sandbox.
$phantomHome = 'C:\PhantomFS'
$phantomBin = Join-Path $phantomHome 'bin'
$virtRoot = Join-Path $phantomHome 'Virtual'

try {
    # ---- 1. Install and load ProjFS ------------------------------------------
    Write-Host 'Installing the host-matched ProjFS binaries inside Windows Sandbox...'
    Copy-Item -LiteralPath (Join-Path $read 'prjflt.sys') -Destination "$env:SystemRoot\System32\drivers\prjflt.sys" -Force
    Copy-Item -LiteralPath (Join-Path $read 'ProjectedFSLib.dll') -Destination "$env:SystemRoot\System32\ProjectedFSLib.dll" -Force

    Write-Host 'Importing the PrjFlt minifilter service registration...'
    & reg.exe import (Join-Path $read 'PrjFlt-service.reg') | Out-Host
    if ($LASTEXITCODE -ne 0) { throw 'reg.exe failed to import PrjFlt-service.reg.' }

    Write-Host 'Loading the ProjFS minifilter manually...'
    $filterList = (& fltmc.exe filters 2>&1 | Out-String)
    if ($filterList -notmatch '(?im)PrjFlt|ProjFS') {
        & fltmc.exe load PrjFlt 2>&1 | Out-Host
        if ($LASTEXITCODE -ne 0) {
            & sc.exe start PrjFlt 2>&1 | Out-Host
        }
    }

    $filterList = (& fltmc.exe filters 2>&1 | Out-String)
    $filterList | Set-Content -LiteralPath (Join-Path $write 'fltmc-filters.txt')
    if ($filterList -notmatch '(?im)PrjFlt|ProjFS') {
        throw 'The ProjFS minifilter did not appear in fltmc filters. See sandbox-bootstrap.log.'
    }

    # ---- 2. Unzip the bundled PhantomFS release ------------------------------
    # The read share is read-only, so expand into a writable location. Match by
    # pattern so a newer PhantomFS-vX.Y.Z-x64.zip needs no changes here.
    $phantomZip = Get-ChildItem -LiteralPath $read -Filter 'PhantomFS-*-x64.zip' -File |
        Sort-Object Name -Descending |
        Select-Object -First 1
    if (-not $phantomZip) { throw "No PhantomFS-*-x64.zip found in $read." }

    Write-Host ("Unzipping {0} to {1}..." -f $phantomZip.Name, $phantomBin)
    if (Test-Path $phantomBin) { Remove-Item -LiteralPath $phantomBin -Recurse -Force }
    New-Item -ItemType Directory -Path $phantomBin -Force | Out-Null
    Expand-Archive -LiteralPath $phantomZip.FullName -DestinationPath $phantomBin -Force

    # The release zip nests the payload under an x64\ folder. Locate the exe
    # wherever it landed rather than assuming a fixed depth.
    $phantomExe = Get-ChildItem -LiteralPath $phantomBin -Filter 'PhantomFS.exe' -File -Recurse |
        Select-Object -First 1
    if (-not $phantomExe) { throw "PhantomFS.exe was not found after unzipping into $phantomBin." }
    Write-Host ("PhantomFS executable: {0}" -f $phantomExe.FullName)

    # ---- 3. Prepare the virtual honeypot root and launch ---------------------
    if (Test-Path $virtRoot) { Remove-Item -LiteralPath $virtRoot -Recurse -Force }
    New-Item -ItemType Directory -Path $virtRoot -Force | Out-Null

    Write-Host 'Starting the PhantomFS honeypot provider...'
    $phantomOut = Join-Path $write 'phantomfs-console.log'
    $phantomErr = Join-Path $write 'phantomfs-error.log'

    # --syntheticonly : project only the decoy files from PhantomFS.exe.config.
    # --service       : run non-interactively and block until stopped, so the
    #                   provider keeps running after this bootstrap returns.
    $arguments = @(
        '--virtroot', ('"{0}"' -f $virtRoot),
        '--syntheticonly',
        '--service'
    )
    $process = Start-Process -FilePath $phantomExe.FullName -ArgumentList $arguments `
        -WorkingDirectory $phantomExe.DirectoryName -WindowStyle Minimized -PassThru `
        -RedirectStandardOutput $phantomOut -RedirectStandardError $phantomErr
    $process.Id | Set-Content -LiteralPath (Join-Path $write 'phantomfs.pid')

    # Wait for the provider to project its decoy tree into the virtual root.
    $deadline = (Get-Date).AddSeconds(20)
    $projected = $false
    while ((Get-Date) -lt $deadline) {
        if ($process.HasExited) {
            throw "PhantomFS exited early with code $($process.ExitCode). See $phantomErr"
        }
        # Decoy entries (for example \AWS, \SSH Keys) appear as ProjFS
        # placeholders under the virtual root once virtualization is live.
        if (@(Get-ChildItem -LiteralPath $virtRoot -Force -ErrorAction SilentlyContinue).Count -gt 0) {
            $projected = $true
            break
        }
        Start-Sleep -Milliseconds 400
    }

    Write-Host ''
    if ($projected) {
        Write-Host 'PhantomFS honeypot is running.' -ForegroundColor Green
    } else {
        Write-Host 'PhantomFS started, but no decoy files were visible yet.' -ForegroundColor Yellow
        Write-Host 'Open the virtual root in Explorer to trigger projection.'
    }
    Write-Host "Virtual honeypot root: $virtRoot"
    Write-Host "Provider PID:          $($process.Id)"
    Write-Host "Console log:           $phantomOut"
    Write-Host ''
    Write-Host 'Open a decoy file to fire an alert. Check Event Viewer ->'
    Write-Host 'Windows Logs -> Application, source PhantomFS (Event IDs 1001-1004).'

    Start-Process explorer.exe -ArgumentList $virtRoot
}
catch {
    $_ | Out-String | Set-Content -LiteralPath (Join-Path $write 'FAILED.txt')
    Write-Error $_
    Start-Process notepad.exe -ArgumentList (Join-Path $write 'FAILED.txt')
}
finally {
    Stop-Transcript | Out-Null
}
