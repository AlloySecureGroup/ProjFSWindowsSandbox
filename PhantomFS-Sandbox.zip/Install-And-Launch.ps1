#requires -version 5.1
# ============================================================================
# PhantomFS in Windows Sandbox - host preparation and launcher
# ----------------------------------------------------------------------------
# Prepares a Windows Sandbox session that manually loads the host-matched
# Windows Projected File System (ProjFS) components, then unzips and runs the
# PhantomFS honeypot provider inside the disposable sandbox.
#
# This script runs on the HOST. It:
#   1. Ensures ProjFS is enabled on the host (needed to obtain the signed
#      driver, DLL, and matching PrjFlt service registration).
#   2. Copies the host-matched prjflt.sys, ProjectedFSLib.dll, the bootstrap,
#      and the bundled PhantomFS release zip into C:\Sandbox\Read.
#   3. Exports the host PrjFlt minifilter service registration.
#   4. Writes the sandbox configuration and launches it.
# ============================================================================
[CmdletBinding()]
param(
    [switch]$NoLaunch
)

$ErrorActionPreference = 'Stop'

function Test-IsAdministrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

if (-not (Test-IsAdministrator)) {
    $argList = @(
        '-NoProfile',
        '-ExecutionPolicy', 'Bypass',
        '-File', ('"{0}"' -f $PSCommandPath)
    )
    if ($NoLaunch) { $argList += '-NoLaunch' }
    Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList $argList
    exit
}

$packageRoot = Split-Path -Parent $PSCommandPath
$base = 'C:\Sandbox'
$read = Join-Path $base 'Read'
$write = Join-Path $base 'Write'
$wsb = Join-Path $base 'PhantomFS-Sandbox.wsb'

New-Item -ItemType Directory -Path $read, $write -Force | Out-Null

# Locate the bundled PhantomFS release zip next to this script. Matching by
# pattern rather than a fixed version means dropping in a newer
# PhantomFS-vX.Y.Z-x64.zip just works with no edits to this script.
$phantomZip = Get-ChildItem -LiteralPath $packageRoot -Filter 'PhantomFS-*-x64.zip' -File |
    Sort-Object Name -Descending |
    Select-Object -First 1
if (-not $phantomZip) {
    throw "No PhantomFS-*-x64.zip found next to this script in $packageRoot. Place the PhantomFS release zip in the package folder."
}

Write-Host '[1/5] Ensuring Windows Projected File System is enabled on the host...'
$feature = Get-WindowsOptionalFeature -Online -FeatureName 'Client-ProjFS'
if ($feature.State -ne 'Enabled') {
    $result = Enable-WindowsOptionalFeature -Online -FeatureName 'Client-ProjFS' -All -NoRestart
    if ($result.RestartNeeded) {
        Write-Warning 'ProjFS was enabled, but Windows requires a restart. Restart the host, then run this script again.'
        exit 3010
    }
}

$driver = Join-Path $env:SystemRoot 'System32\drivers\prjflt.sys'
$dll = Join-Path $env:SystemRoot 'System32\ProjectedFSLib.dll'
if (-not (Test-Path $driver)) { throw "ProjFS driver was not found at $driver" }
if (-not (Test-Path $dll)) { throw "ProjFS DLL was not found at $dll" }

Write-Host '[2/5] Copying ProjFS driver, DLL, bootstrap, and PhantomFS payload to C:\Sandbox\Read...'
Copy-Item -LiteralPath $driver -Destination $read -Force
Copy-Item -LiteralPath $dll -Destination $read -Force
Copy-Item -LiteralPath (Join-Path $packageRoot 'Sandbox-Bootstrap.ps1') -Destination $read -Force
Copy-Item -LiteralPath $phantomZip.FullName -Destination $read -Force
Write-Host ("       Bundled provider: {0}" -f $phantomZip.Name)

Write-Host '[3/5] Exporting the host-matched PrjFlt minifilter service registration...'
$serviceKey = 'HKLM\SYSTEM\CurrentControlSet\Services\PrjFlt'
$regFile = Join-Path $read 'PrjFlt-service.reg'
& reg.exe query $serviceKey *> $null
if ($LASTEXITCODE -ne 0) {
    throw "The $serviceKey registry key does not exist. Enable ProjFS and restart Windows before retrying."
}
& reg.exe export $serviceKey $regFile /y | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Failed to export the PrjFlt service registry key.' }

Write-Host '[4/5] Creating the Windows Sandbox configuration...'
$wsbXml = @'
<Configuration>
  <VGpu>Disable</VGpu>
  <Networking>Disable</Networking>
  <ClipboardRedirection>Enable</ClipboardRedirection>
  <MemoryInMB>4096</MemoryInMB>
  <MappedFolders>
    <MappedFolder>
      <HostFolder>C:\Sandbox\Read</HostFolder>
      <SandboxFolder>C:\Sandbox\Read</SandboxFolder>
      <ReadOnly>true</ReadOnly>
    </MappedFolder>
    <MappedFolder>
      <HostFolder>C:\Sandbox\Write</HostFolder>
      <SandboxFolder>C:\Sandbox\Write</SandboxFolder>
      <ReadOnly>false</ReadOnly>
    </MappedFolder>
  </MappedFolders>
  <LogonCommand>
    <Command>powershell.exe -NoProfile -ExecutionPolicy Bypass -File C:\Sandbox\Read\Sandbox-Bootstrap.ps1</Command>
  </LogonCommand>
</Configuration>
'@
Set-Content -LiteralPath $wsb -Value $wsbXml -Encoding UTF8

Write-Host '[5/5] Host preparation complete.' -ForegroundColor Green
Write-Host "Read-only payload: $read"
Write-Host "Sandbox output:    $write"
Write-Host "Sandbox config:    $wsb"

if (-not $NoLaunch) {
    Write-Host 'Launching Windows Sandbox...'
    Start-Process -FilePath $wsb
}
