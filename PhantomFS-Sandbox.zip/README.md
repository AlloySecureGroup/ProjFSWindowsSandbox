# PhantomFS in Windows Sandbox

This package boots a Windows Sandbox session that manually loads the Windows
Projected File System (ProjFS) components, then unzips and runs the
[PhantomFS](https://github.com/AlloySecureGroup/PhantomFS) honeypot provider
automatically on start. It merges the sandbox bootstrapping technique from
[ProjFSWindowsSandbox](https://github.com/AlloySecureGroup/ProjFSWindowsSandbox)
with a bundled PhantomFS release so the whole thing deploys as a single zip.

Windows Sandbox does not ship with ProjFS enabled, and its networking is
disabled here for isolation, so PhantomFS is bundled inside this package rather
than downloaded at runtime.

## What is in the package

| File | Role |
|---|---|
| `Install-And-Launch.ps1` | Runs on the host. Stages ProjFS binaries plus the PhantomFS zip, writes the sandbox config, and launches it. |
| `Sandbox-Bootstrap.ps1` | Runs inside the sandbox. Loads ProjFS, unzips PhantomFS, and starts the provider. |
| `PhantomFS-vX.Y.Z-x64.zip` | The bundled PhantomFS release (`PhantomFS.exe` and `PhantomFS.exe.config`). |
| `PhantomFS-Sandbox.wsb` | Sandbox configuration for relaunching manually after host prep. |
| `LICENSE` | MIT license. |

## Run

1. Extract this zip on the Windows host.

2. Right-click `Install-And-Launch.ps1` and choose **Run with PowerShell**, or run:

   ```
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Install-And-Launch.ps1
   ```

3. Approve the administrator prompt.

4. If the script enables ProjFS and requests a restart, restart Windows and rerun it.

5. Windows Sandbox launches automatically. The bootstrap copies the driver and
   DLL, imports the host `PrjFlt` service registration, loads the minifilter,
   unzips PhantomFS, starts the provider against `C:\PhantomFS\Virtual`, and
   opens that folder in Explorer.

## Try it

Inside the sandbox, browse to `C:\PhantomFS\Virtual`. You will see decoy
directories such as `AWS`, `SSH Keys`, and `API Keys` projected on demand. Open
any decoy file to fire an alert, then check **Event Viewer -> Windows Logs ->
Application** and filter by source `PhantomFS`.

| Event ID | Meaning |
|---|---|
| 1001 | A decoy file's data was read |
| 1002 | A decoy placeholder was created (browsed) |
| 1003 | PhantomFS started |
| 1004 | PhantomFS stopped |

## Paths

- Host staging, mapped read-only: `C:\Sandbox\Read`
- Host and sandbox logs, mapped writable: `C:\Sandbox\Write`
- PhantomFS install location in the sandbox: `C:\PhantomFS\bin`
- Virtual honeypot root in the sandbox: `C:\PhantomFS\Virtual`

## Logs

Written to `C:\Sandbox\Write`, which survives after the sandbox closes:

- `sandbox-bootstrap.log` transcript of the bootstrap
- `fltmc-filters.txt` loaded minifilters (proves ProjFS loaded)
- `phantomfs-console.log` and `phantomfs-error.log` provider output
- `phantomfs.pid` process id of the running provider
- `FAILED.txt` written only if the bootstrap hits an error

## How the launch flow works

The provider is started with:

```
PhantomFS.exe --virtroot C:\PhantomFS\Virtual --syntheticonly --service
```

`--syntheticonly` projects only the decoy files defined in
`PhantomFS.exe.config`. `--service` runs the provider non-interactively so it
keeps running after the bootstrap script returns, instead of waiting for a
console keypress.

To swap in a newer PhantomFS build, replace the `PhantomFS-*-x64.zip` in this
folder. Both scripts pick the zip up by pattern, so no edits are needed.

## Updating the decoy files

The decoy file tree and content templates live in `PhantomFS.exe.config`
inside the bundled zip. Edit that config (or generate one with the
[PhantomFS Profile Builder](https://alloysecuregroup.github.io/PhantomFS/)),
rezip it as `PhantomFS-<version>-x64.zip` with the same internal `x64\` layout,
and drop it back into this package.

## Manual relaunch

After host preparation, launch `C:\Sandbox\PhantomFS-Sandbox.wsb` directly.

## Important limitations

- This is an experimental and unsupported technique. Windows Sandbox normally
  gets Windows components from its base image. Manually copying and registering
  a kernel minifilter can be rejected by servicing, code-integrity, or
  build-mismatch checks.
- The package deliberately copies the driver, DLL, and complete `PrjFlt`
  registry configuration from the same host build. Do not substitute files from
  another machine or Windows build.
- Secure Boot and code integrity remain enforced. The Microsoft-signed host
  binary should load only when compatible with the sandbox kernel.
- Windows Sandbox is disposable. All in-sandbox changes disappear when it
  closes. Only the writable mapped folder survives.
- Networking is disabled by the supplied `.wsb`, which is why PhantomFS is
  bundled rather than downloaded. Toast notifications may not surface reliably
  inside the sandbox, but Event Log entries still fire.

## Attribution

- ProjFS in Windows Sandbox technique: https://github.com/AlloySecureGroup/ProjFSWindowsSandbox
- PhantomFS honeypot: https://github.com/AlloySecureGroup/PhantomFS

Both are MIT licensed by Alloy Secure.
